from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/home")
def about_me():
    return render_template("Home.html")

@app.route("/form")
def form():
    return render_template("form.html")

@app.route("/submit", methods=["POST"])
def submit():
    firstname = request.form.get("firstname")
    lastname = request.form.get("lastname")
    email = request.form.get("email")
    favoritefood = request.form.get("favoritefood")
    return render_template("submit.html", firstname=firstname,lastname=lastname, email=email, favoritefood=favoritefood)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)