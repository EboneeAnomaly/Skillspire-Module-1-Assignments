from flask import Flask, render_template

app = Flask(__name__)

@app.route("/home")
def about_me():
    return "<strong>Full Name:</strong> Ebonee Singleteary <br> <strong>Favorite Food:</strong> Gumbo <br> <strong>Favorite Vacation Destination:</strong> New Orleans"

if __name__ == "__main__":
    app.run()