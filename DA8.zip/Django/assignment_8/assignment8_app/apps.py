from django.apps import AppConfig


class Assigment8AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'assignment8_app'
