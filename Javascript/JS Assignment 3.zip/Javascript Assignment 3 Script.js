
let age = window.prompt("Please enter your age.");

if(age === "16"){
console.log("Stay home, study, and get your drivers license.")
}
else if(age === "18"){
console.log("Have some fun, but not TOO much fun. You're still a young adult.")
}
else{
console.log("Have fun. But be responsible. You are in control of your life.")

}

