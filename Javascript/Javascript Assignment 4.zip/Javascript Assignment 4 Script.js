let info = window.prompt("Please enter your Full Name, Favorite Food, and Favorite Activity.")

// I assigned a value to 'info', which is where the enter info is stored
// I used 'window.prompt' to call up a window in the browser to enter 'info' in

document.write('<div><h1>'+ info +'</h1></div>')
// I used 'document.write() to write directly to the body, and I styled 'info' with the required 'h1' heading tag.

//on my html page, I placed the script within the body, because where you place your script tags is where 'the document.write()' content will appear.